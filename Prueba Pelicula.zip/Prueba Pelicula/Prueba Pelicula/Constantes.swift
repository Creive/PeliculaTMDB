//
//  Constantes.swift
//  Prueba Pelicula
//
//  Created by NECSOFT on 24/10/21.
//

import Foundation
class Constantes{
    static let URL = "https://api.themoviedb.org/3/movie/"
    static let Api = "cbe294618dcbf375a57eb9dfad840a69"
    static let top_Rated = "top_rated?"
    static let upcoming = "upcoming?"
    static let popular = "popular?"
    static let nowplaying = "now_playing?"
    static let latest = "latest?"
    static let urlImagenes = "https://www.themoviedb.org/t/p/w1280"
    static let defaul = "Mejor Valorado"
    static let menu = ["Mejor Valorado", "Estrenos","Proximamente","Popular"]
    
    
}
